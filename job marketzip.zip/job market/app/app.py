import os
import sys
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Add src to Python path for database operations
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

from src.auth_db import (
    register_user,
    authenticate_user,
    save_user_assessment,
    get_user_assessments,
    delete_user_assessment,
    save_job_bookmark,
    get_saved_jobs,
    delete_saved_job
)

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="Job Market & Skills Demand Analytics",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- INITIALIZE SESSION STATE ---
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "user" not in st.session_state:
    st.session_state.user = None
if "loaded_assessment" not in st.session_state:
    st.session_state.loaded_assessment = None

# --- CUSTOM CSS ---
st.markdown("""
<style>
    .metric-card {
        background-color: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
        border: 1px solid #e9ecef;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 12px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 48px;
        white-space: pre-wrap;
        font-weight: 600;
    }
    .user-profile-box {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        color: white;
        padding: 14px;
        border-radius: 10px;
        margin-bottom: 15px;
    }
    .record-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
</style>
""", unsafe_allow_html=True)

# --- LOAD DATA ---
@st.cache_data
def load_data():
    cleaned_jobs_path = os.path.join(BASE_DIR, "data", "processed", "cleaned_jobs.csv")
    skills_summary_path = os.path.join(BASE_DIR, "data", "processed", "skills_summary.csv")
    skills_role_path = os.path.join(BASE_DIR, "data", "processed", "skills_by_role.csv")

    df = pd.read_csv(cleaned_jobs_path)
    skills_df = pd.read_csv(skills_summary_path)
    skills_role_df = pd.read_csv(skills_role_path)
    
    return df, skills_df, skills_role_df

try:
    df, skills_df, skills_role_df = load_data()
except Exception as e:
    st.error(f"Error loading dataset: {e}. Please ensure you ran `python src/data_processing.py`.")
    st.stop()

# ==========================================
# SIDEBAR: USER AUTHENTICATION & PROFILE
# ==========================================
st.sidebar.markdown("### 👤 User Account")

if not st.session_state.logged_in:
    auth_mode = st.sidebar.radio("Sign in or create account to save records:", ["🔑 Login", "📝 Register"], horizontal=True)

    if auth_mode == "🔑 Login":
        with st.sidebar.form("login_form"):
            login_username = st.text_input("Username")
            login_password = st.text_input("Password", type="password")
            login_submit = st.form_submit_button("Log In", use_container_width=True)

            if login_submit:
                if not login_username or not login_password:
                    st.error("Please fill in both fields.")
                else:
                    success, result = authenticate_user(login_username, login_password)
                    if success:
                        st.session_state.logged_in = True
                        st.session_state.user = result
                        st.sidebar.success(f"Welcome back, {result['username']}!")
                        st.rerun()
                    else:
                        st.sidebar.error(result)

    else:
        with st.sidebar.form("register_form"):
            reg_username = st.text_input("Username")
            reg_email = st.text_input("Email (Optional)")
            reg_password = st.text_input("Password", type="password")
            reg_confirm = st.text_input("Confirm Password", type="password")
            reg_submit = st.form_submit_button("Create Account", use_container_width=True)

            if reg_submit:
                if not reg_username or not reg_password:
                    st.sidebar.error("Username and password are required.")
                elif reg_password != reg_confirm:
                    st.sidebar.error("Passwords do not match.")
                else:
                    success, result = register_user(reg_username, reg_password, reg_email)
                    if success:
                        st.session_state.logged_in = True
                        st.session_state.user = result
                        st.sidebar.success(f"Account created! Welcome, {result['username']}!")
                        st.rerun()
                    else:
                        st.sidebar.error(result)

else:
    # User is logged in
    user_info = st.session_state.user
    user_assessments = get_user_assessments(user_info["id"])
    user_saved_jobs = get_saved_jobs(user_info["id"])

    st.sidebar.markdown(f"""
    <div class="user-profile-box">
        <h4 style="margin:0; color:white;">👋 {user_info['username']}</h4>
        <p style="margin:5px 0 0 0; font-size: 0.85rem; opacity: 0.9;">
            📁 <b>{len(user_assessments)}</b> Saved Assessments<br>
            ⭐ <b>{len(user_saved_jobs)}</b> Bookmarked Jobs
        </p>
    </div>
    """, unsafe_allow_html=True)

    if st.sidebar.button("🚪 Log Out", use_container_width=True):
        st.session_state.logged_in = False
        st.session_state.user = None
        st.session_state.loaded_assessment = None
        st.rerun()

st.sidebar.markdown("---")

# ==========================================
# SIDEBAR: DATASET FILTERS
# ==========================================
st.sidebar.title("🔍 Filter Job Market")
st.sidebar.markdown("Click on any box below to filter options. *(Leave empty to include all)*")

# Job Roles Filter
all_roles = sorted(df['job_role'].unique())
selected_roles = st.sidebar.multiselect(
    "Job Role:",
    options=all_roles,
    default=[],
    placeholder="Showing all roles (Click to filter)"
)
active_roles = selected_roles if selected_roles else all_roles

# Countries Filter
all_countries = sorted(df['country'].unique())
selected_countries = st.sidebar.multiselect(
    "Country:",
    options=all_countries,
    default=[],
    placeholder="Showing all countries (Click to filter)"
)
active_countries = selected_countries if selected_countries else all_countries

# Experience Levels Filter
all_exp = ["Entry-level", "Mid-level", "Senior-level", "Lead/Principal"]
selected_exp = st.sidebar.multiselect(
    "Experience Level:",
    options=all_exp,
    default=[],
    placeholder="Showing all experience levels"
)
active_exp = selected_exp if selected_exp else all_exp

# Work Type Filter
all_work_types = sorted(df['work_type'].unique())
selected_work_types = st.sidebar.multiselect(
    "Work Arrangement:",
    options=all_work_types,
    default=[],
    placeholder="Showing Remote, Hybrid & On-site"
)
active_work_types = selected_work_types if selected_work_types else all_work_types

# Salary Range
min_salary = int(df['salary_year_usd'].min())
max_salary = int(df['salary_year_usd'].max())
selected_salary = st.sidebar.slider(
    "Annual Salary Range (USD):",
    min_value=min_salary,
    max_value=max_salary,
    value=(min_salary, max_salary),
    step=5000
)

# Apply filters
filtered_df = df[
    (df['job_role'].isin(active_roles)) &
    (df['country'].isin(active_countries)) &
    (df['experience_level'].isin(active_exp)) &
    (df['work_type'].isin(active_work_types)) &
    (df['salary_year_usd'] >= selected_salary[0]) &
    (df['salary_year_usd'] <= selected_salary[1])
]

# --- MAIN TITLE ---
st.title("💼 Job Market & Skills Demand Analytics")
st.markdown("An interactive end-to-end data analytics dashboard tracking tech & data hiring trends, salary benchmarks, and personalized career profiles.")

# --- ACTIVE FILTER STATUS BADGES ---
filter_summary = []
if selected_roles:
    filter_summary.append(f"**Roles:** {', '.join(selected_roles)}")
if selected_countries:
    filter_summary.append(f"**Countries:** {', '.join(selected_countries)}")
if selected_exp:
    filter_summary.append(f"**Levels:** {', '.join(selected_exp)}")
if selected_work_types:
    filter_summary.append(f"**Work Types:** {', '.join(selected_work_types)}")

if filter_summary:
    st.info("🎯 **Active Filters Applied:** " + " | ".join(filter_summary))

# --- TOP KPI METRICS ---
col1, col2, col3, col4, col5 = st.columns(5)

with col1:
    st.metric(label="Total Postings", value=f"{len(filtered_df):,}")

with col2:
    avg_sal = filtered_df['salary_year_usd'].mean() if not filtered_df.empty else 0
    st.metric(label="Avg Salary (USD)", value=f"${avg_sal:,.0f}")

with col3:
    med_sal = filtered_df['salary_year_usd'].median() if not filtered_df.empty else 0
    st.metric(label="Median Salary (USD)", value=f"${med_sal:,.0f}")

with col4:
    remote_pct = (filtered_df['work_type'] == 'Remote').mean() * 100 if not filtered_df.empty else 0
    st.metric(label="Remote Postings", value=f"{remote_pct:.1f}%")

with col5:
    top_skill = skills_df.iloc[0]['skill'] if not skills_df.empty else "N/A"
    st.metric(label="Top Overall Skill", value=top_skill)

st.markdown("---")

if filtered_df.empty:
    st.warning("⚠️ No job postings match your selected filters. Please adjust your filter criteria in the sidebar.")
    st.stop()

# --- TABS ---
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📊 Market Overview", 
    "🛠️ Skills Demand & ROI", 
    "💰 Salary & Jobs Table", 
    "🎯 Skills Matcher & Advisory",
    "📁 My Saved Records & History"
])

# ==========================================
# TAB 1: MARKET OVERVIEW
# ==========================================
with tab1:
    st.subheader("Industry Hiring Distribution")
    
    c1, c2 = st.columns(2)
    with c1:
        role_counts = filtered_df['job_role'].value_counts().reset_index()
        role_counts.columns = ['Job Role', 'Postings']
        fig_role = px.bar(
            role_counts, 
            x='Postings', 
            y='Job Role', 
            orientation='h',
            title="Job Postings by Role",
            color='Postings',
            color_continuous_scale="Viridis"
        )
        fig_role.update_layout(yaxis={'categoryorder': 'total ascending'}, height=380)
        st.plotly_chart(fig_role, use_container_width=True)

    with c2:
        work_counts = filtered_df['work_type'].value_counts().reset_index()
        work_counts.columns = ['Work Type', 'Count']
        fig_work = px.pie(
            work_counts, 
            names='Work Type', 
            values='Count', 
            hole=0.45,
            title="Work Arrangement (Remote vs Hybrid vs On-site)",
            color_discrete_sequence=px.colors.qualitative.Pastel
        )
        fig_work.update_layout(height=380)
        st.plotly_chart(fig_work, use_container_width=True)

    c3, c4 = st.columns(2)
    with c3:
        country_counts = filtered_df['country'].value_counts().reset_index()
        country_counts.columns = ['Country', 'Postings']
        fig_country = px.bar(
            country_counts,
            x='Country',
            y='Postings',
            title="Postings by Country",
            color='Country',
            color_discrete_sequence=px.colors.qualitative.Safe
        )
        fig_country.update_layout(height=360, showlegend=False)
        st.plotly_chart(fig_country, use_container_width=True)

    with c4:
        comp_counts = filtered_df['company_size'].value_counts().reset_index()
        comp_counts.columns = ['Company Size', 'Postings']
        fig_comp = px.bar(
            comp_counts,
            x='Company Size',
            y='Postings',
            title="Demand by Company Size",
            color='Company Size',
            color_discrete_sequence=px.colors.qualitative.Set2
        )
        fig_comp.update_layout(height=360, showlegend=False)
        st.plotly_chart(fig_comp, use_container_width=True)

# ==========================================
# TAB 2: SKILLS DEMAND & ROI
# ==========================================
with tab2:
    st.subheader("Skills Demand vs Earning Potential")
    
    col_s1, col_s2 = st.columns(2)
    with col_s1:
        top_n = st.slider("Select Top N Skills to Display", min_value=5, max_value=30, value=15)
        top_skills = skills_df.head(top_n)
        fig_skills = px.bar(
            top_skills,
            x='demand_percentage',
            y='skill',
            orientation='h',
            title=f"Top {top_n} Most Demanded Skills (% of All Postings)",
            color='demand_percentage',
            color_continuous_scale="Blues",
            labels={'demand_percentage': 'Demand (% of Postings)', 'skill': 'Skill'}
        )
        fig_skills.update_layout(yaxis={'categoryorder': 'total ascending'}, height=480)
        st.plotly_chart(fig_skills, use_container_width=True)

    with col_s2:
        top_paying = skills_df.sort_values(by='avg_salary', ascending=False).head(top_n)
        fig_paying = px.bar(
            top_paying,
            x='avg_salary',
            y='skill',
            orientation='h',
            title=f"Top {top_n} Highest Paying Skills (Avg Annual USD)",
            color='avg_salary',
            color_continuous_scale="Emrld",
            labels={'avg_salary': 'Avg Salary (USD)', 'skill': 'Skill'}
        )
        fig_paying.update_layout(yaxis={'categoryorder': 'total ascending'}, height=480)
        st.plotly_chart(fig_paying, use_container_width=True)

    st.markdown("#### 🎯 Skill Value Quadrant: Demand % vs Median Salary")
    fig_scatter = px.scatter(
        skills_df,
        x='demand_percentage',
        y='median_salary',
        size='job_count',
        text='skill',
        color='avg_salary',
        color_continuous_scale='Turbo',
        labels={'demand_percentage': 'Market Demand (%)', 'median_salary': 'Median Salary ($)'},
        title="Skill Value Map (Bubble Size = Job Count)"
    )
    fig_scatter.update_traces(textposition='top center')
    fig_scatter.update_layout(height=520)
    st.plotly_chart(fig_scatter, use_container_width=True)

    st.markdown("#### 🔍 In-Demand Skills by Specific Role")
    selected_role_tab2 = st.selectbox("Select Role to Inspect Skills:", options=all_roles, index=0)
    role_skills_filtered = skills_role_df[skills_role_df['job_role'] == selected_role_tab2].head(12)
    
    fig_role_skills = px.bar(
        role_skills_filtered,
        x='demand_percentage',
        y='skill',
        orientation='h',
        title=f"Must-Have Skills for {selected_role_tab2}",
        color='demand_percentage',
        color_continuous_scale="Tealgrn",
        labels={'demand_percentage': 'Demand within Role (%)'}
    )
    fig_role_skills.update_layout(yaxis={'categoryorder': 'total ascending'}, height=400)
    st.plotly_chart(fig_role_skills, use_container_width=True)

# ==========================================
# TAB 3: SALARY & JOBS TABLE (WITH BOOKMARKING)
# ==========================================
with tab3:
    st.subheader("Salary Benchmarks & Job Explorer")

    col_sal1, col_sal2 = st.columns(2)
    with col_sal1:
        fig_box = px.box(
            filtered_df,
            x='experience_level',
            y='salary_year_usd',
            color='experience_level',
            title="Salary Distribution by Experience Level",
            category_orders={'experience_level': ["Entry-level", "Mid-level", "Senior-level", "Lead/Principal"]}
        )
        fig_box.update_layout(height=420, showlegend=False)
        st.plotly_chart(fig_box, use_container_width=True)

    with col_sal2:
        avg_role_sal = filtered_df.groupby('job_role')['salary_year_usd'].mean().reset_index()
        avg_role_sal = avg_role_sal.sort_values(by='salary_year_usd', ascending=True)
        fig_role_sal = px.bar(
            avg_role_sal,
            x='salary_year_usd',
            y='job_role',
            orientation='h',
            title="Average Salary by Role (USD)",
            color='salary_year_usd',
            color_continuous_scale='Magma'
        )
        fig_role_sal.update_layout(height=420)
        st.plotly_chart(fig_role_sal, use_container_width=True)

    st.markdown("#### 📋 Filtered Postings Data Table")
    st.dataframe(
        filtered_df[['job_id', 'job_title', 'job_role', 'company_name', 'country', 'work_type', 'experience_level', 'salary_year_usd', 'skills']],
        use_container_width=True,
        hide_index=True
    )

    # Bookmark a Job Section
    st.markdown("#### ⭐ Bookmark a Job to Your Profile")
    if not filtered_df.empty:
        job_options = {
            f"{r['job_id']} - {r['job_title']} at {r['company_name']} (${r['salary_year_usd']:,})": r
            for _, r in filtered_df.head(100).iterrows()
        }
        chosen_job_label = st.selectbox("Select a job from above to bookmark:", options=list(job_options.keys()))
        
        if st.button("⭐ Save Job to Bookmarks"):
            if not st.session_state.logged_in:
                st.warning("⚠️ Please Log In or Register in the sidebar to bookmark jobs to your personal account.")
            else:
                job_data = job_options[chosen_job_label].to_dict()
                success, msg = save_job_bookmark(st.session_state.user["id"], job_data)
                if success:
                    st.success(f"✅ {msg}")
                else:
                    st.info(f"ℹ️ {msg}")

# ==========================================
# TAB 4: SKILLS MATCHER & ADVISORY (WITH SAVE)
# ==========================================
with tab4:
    st.subheader("🎯 Career Skill-Gap Analyzer")
    st.markdown("Select your target role and check your current skills to calculate your match score and get recommendations.")

    # Check if user loaded a saved assessment
    default_role = all_roles[0]
    default_skills = []
    
    if st.session_state.loaded_assessment:
        loaded = st.session_state.loaded_assessment
        if loaded["target_role"] in all_roles:
            default_role = loaded["target_role"]
        loaded_skills = [s.strip() for s in loaded["skills_possessed"].split(",") if s.strip()]
        default_skills = [s for s in loaded_skills if s in skills_df['skill'].values]
        st.info(f"📂 Loaded Saved Record: **{loaded['assessment_name']}** (Role: {loaded['target_role']})")
        if st.button("✕ Clear Loaded Record"):
            st.session_state.loaded_assessment = None
            st.rerun()

    col_m1, col_m2 = st.columns([1, 1])

    with col_m1:
        target_role = st.selectbox(
            "1. Choose Target Career Path:",
            options=all_roles,
            index=all_roles.index(default_role) if default_role in all_roles else 0
        )
        
        # Get all relevant skills for this role
        role_skills_all = skills_role_df[skills_role_df['job_role'] == target_role].sort_values(by='demand_percentage', ascending=False)
        top_skills_for_role = list(role_skills_all['skill'].unique())
        
        if not default_skills and len(top_skills_for_role) >= 2:
            default_skills = [top_skills_for_role[0], top_skills_for_role[1]]

        user_skills = st.multiselect(
            "2. Select the Skills You Currently Possess:",
            options=sorted(list(skills_df['skill'].unique())),
            default=[s for s in default_skills if s in skills_df['skill'].values]
        )

    matched_skills = []
    missing_skills = []
    match_score = 0.0

    with col_m2:
        if top_skills_for_role:
            matched_skills = [s for s in user_skills if s in top_skills_for_role[:10]]
            missing_skills = [s for s in top_skills_for_role[:10] if s not in user_skills]
            match_score = (len(matched_skills) / 10.0) * 100

            st.markdown(f"### Job Fit Score: **{match_score:.0f}%**")
            st.progress(match_score / 100.0)

            st.write(f"**Matched Core Skills ({len(matched_skills)}/10):**")
            if matched_skills:
                st.success(", ".join(matched_skills))
            else:
                st.info("None of the top 10 core skills selected yet.")

            st.write(f"**Recommended Skills to Learn Next for Higher Compensation:**")
            if missing_skills:
                rec_df = role_skills_all[role_skills_all['skill'].isin(missing_skills)].head(5)
                for _, row in rec_df.iterrows():
                    st.write(f"• **{row['skill']}** (Required in {row['demand_percentage']}% of {target_role} roles, Avg Salary: ${row['avg_salary']:,.0f})")
            else:
                st.balloons()
                st.success("🎉 Outstanding! You already match all top 10 in-demand skills for this role!")

    st.markdown("---")
    # Section: Save assessment to user profile
    st.subheader("💾 Save Assessment to Your Personal Records")
    if not st.session_state.logged_in:
        st.warning("🔒 **Want to save this assessment?** Please Log In or Register using the sidebar to store your career scores permanently.")
    else:
        with st.expander("📝 Save This Career Assessment Record", expanded=True):
            col_save1, col_save2 = st.columns([1, 1])
            with col_save1:
                rec_name = st.text_input("Record Name:", value=f"{target_role} Assessment")
                rec_notes = st.text_area("Personal Notes / Learning Goals:", placeholder="e.g., Currently completing SQL course; plan to learn PyTorch by end of quarter.")
            with col_save2:
                st.write("**Summary of Record to be Saved:**")
                st.write(f"• **Role:** {target_role}")
                st.write(f"• **Fit Score:** {match_score:.0f}%")
                st.write(f"• **Skills Count:** {len(user_skills)} skills recorded")
                if st.button("💾 Save to My Records", use_container_width=True):
                    success, msg = save_user_assessment(
                        user_id=st.session_state.user["id"],
                        assessment_name=rec_name,
                        target_role=target_role,
                        skills_possessed=user_skills,
                        fit_score=match_score,
                        missing_skills=missing_skills,
                        notes=rec_notes
                    )
                    if success:
                        st.success(f"✅ {msg} You can view it in the '📁 My Saved Records' tab.")
                    else:
                        st.error(f"❌ Error: {msg}")

# ==========================================
# TAB 5: MY SAVED RECORDS & HISTORY
# ==========================================
with tab5:
    st.subheader("📁 My Personal Records & Bookmarks")

    if not st.session_state.logged_in:
        st.info("🔒 **Access Restricted:** Please **Log In** or **Register** using the sidebar to view and manage your saved career assessments and bookmarked jobs.")
    else:
        user_info = st.session_state.user
        records = get_user_assessments(user_info["id"])
        saved_jobs_list = get_saved_jobs(user_info["id"])

        record_tab1, record_tab2 = st.tabs([
            f"🎯 Saved Skill Assessments ({len(records)})", 
            f"⭐ Bookmarked Jobs ({len(saved_jobs_list)})"
        ])

        with record_tab1:
            if not records:
                st.info("You haven't saved any career assessments yet. Head over to **Tab 4 (🎯 Skills Matcher)** to run an assessment and save it!")
            else:
                st.markdown(f"Displaying **{len(records)}** saved assessment records for **{user_info['username']}**:")
                
                for rec in records:
                    with st.container():
                        st.markdown(f"""
                        <div class="record-card">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <h4 style="margin:0; color:#1e3c72;">📌 {rec['assessment_name']}</h4>
                                <span style="color:#6c757d; font-size:0.85rem;">Saved on: {rec['created_at']}</span>
                            </div>
                            <p style="margin:8px 0 4px 0;"><b>Target Role:</b> {rec['target_role']} | <b>Job Fit Score:</b> <span style="color:#2b6cb0; font-weight:700;">{rec['fit_score']:.0f}%</span></p>
                            <p style="margin:4px 0;"><b>Skills Possessed:</b> {rec['skills_possessed'] or 'None specified'}</p>
                            <p style="margin:4px 0; color:#c53030;"><b>Missing In-Demand Skills:</b> {rec['missing_skills'] or 'None! Complete match'}</p>
                            {f"<p style='margin:4px 0; font-style:italic; color:#4a5568;'><b>Notes:</b> {rec['notes']}</p>" if rec['notes'] else ""}
                        </div>
                        """, unsafe_allow_html=True)

                        c_btn1, c_btn2, c_spacer = st.columns([1.2, 1, 4])
                        with c_btn1:
                            if st.button(f"🔄 Open in Analyzer", key=f"load_{rec['id']}"):
                                st.session_state.loaded_assessment = rec
                                st.success(f"Assessment '{rec['assessment_name']}' loaded! Switch to Tab 4 to view.")
                        with c_btn2:
                            if st.button(f"🗑️ Delete", key=f"del_{rec['id']}"):
                                delete_user_assessment(rec['id'], user_info["id"])
                                st.rerun()
                        st.markdown("<hr style='margin: 10px 0;'>", unsafe_allow_html=True)

        with record_tab2:
            if not saved_jobs_list:
                st.info("You haven't bookmarked any job postings yet. Go to **Tab 3 (💰 Salary & Jobs Table)** to save jobs you are interested in applying to!")
            else:
                saved_df = pd.DataFrame(saved_jobs_list)
                st.dataframe(
                    saved_df[['job_id', 'job_title', 'job_role', 'company_name', 'salary_year_usd', 'country', 'work_type', 'skills', 'saved_at']],
                    use_container_width=True,
                    hide_index=True
                )

                col_del, col_csv = st.columns([2, 1])
                with col_del:
                    del_job_id = st.selectbox(
                        "Select a saved job to remove:",
                        options=[f"{j['id']}: {j['job_title']} at {j['company_name']}" for j in saved_jobs_list]
                    )
                    if st.button("🗑️ Remove Selected Bookmark"):
                        selected_db_id = int(del_job_id.split(":")[0])
                        delete_saved_job(selected_db_id, user_info["id"])
                        st.success("Bookmark removed!")
                        st.rerun()

                with col_csv:
                    csv_data = saved_df.to_csv(index=False).encode('utf-8')
                    st.download_button(
                        label="📥 Export Bookmarks (CSV)",
                        data=csv_data,
                        file_name=f"{user_info['username']}_saved_jobs.csv",
                        mime="text/csv",
                        use_container_width=True
                    )

st.markdown("---")
st.caption("Developed with Python, Pandas, SQLite, Plotly & Streamlit | Job Market Analytics Project")
