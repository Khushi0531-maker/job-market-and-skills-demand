# 💼 Job Market & Skills Demand Analytics

An end-to-end Data Analytics and Business Intelligence project that analyzes hiring patterns, skill demands, and compensation across modern tech and data roles.

---

## 📌 Project Overview
The tech and data job market evolves rapidly. Job seekers, hiring managers, and career switchers often ask:
* *Which programming languages and tools have the highest market demand?*
* *Which skills command the greatest salary premium?*
* *How do skill requirements differ between Data Analysts, Data Scientists, and Data Engineers?*
* *What is the landscape of Remote vs Hybrid work?*

This project provides data-driven answers using real-world job posting analytics and an interactive Streamlit web dashboard with:
* **User Accounts & Authentication:** Secure registration and login backed by SQLite & PBKDF2-SHA256 password hashing.
* **Personal Career Assessment Records:** Save customized skill gap evaluations, fit scores, and target role learning paths.
* **One-Click Reopening:** Load previously saved career evaluations back into the analyzer whenever needed.
* **Job Bookmarking:** Bookmark individual job postings from the live dataset and export them as CSV.

---

## 🚀 Key Insights from the Data
* **Universal Foundations:** **Python (67.9%)** and **SQL (63.0%)** dominate across almost all data roles.
* **Specialized High-Earners:** While Python and SQL have high volume, specialized engineering skills like **MLOps**, **Docker**, **AWS**, and **FastAPI** command the highest average compensation ($120k - $130k+).
* **Remote Work Shift:** **42%** of modern tech postings offer fully remote work, with another **35.7%** supporting hybrid arrangements.
* **Role Focus:**
  * **Data Analyst:** Statistics, SQL, Power BI, Excel, and Tableau.
  * **Data Scientist:** Python, Machine Learning, Scikit-Learn, Statistics, and PyTorch.
  * **Data Engineer:** SQL, Python, Spark, AWS, Airflow, and Snowflake.
  * **Machine Learning Engineer:** MLOps, PyTorch, Docker, Kubernetes, and FastAPI.

---

## 📁 Project Directory Structure
```text
job market/
│
├── data/
│   ├── raw/                  # Raw job postings dataset (CSV)
│   └── processed/            # Cleaned data and skill aggregated tables
│       ├── cleaned_jobs.csv
│       ├── skills_summary.csv
│       └── skills_by_role.csv
│
├── src/
│   ├── generate_dataset.py   # Script to generate/fetch job posting records
│   ├── data_processing.py    # Cleaning, parsing, exploding skills, aggregations
│   └── run_eda.py            # Terminal summary report of key analytics metrics
│
├── app/
│   └── app.py                # Interactive Streamlit Web Dashboard
│
├── requirements.txt          # Python dependencies
├── .gitignore                # Git ignore configuration
└── README.md                 # Project documentation & insights
```

---

## 🛠️ Tech Stack
* **Language:** Python 3.12+
* **Data Processing & Wrangling:** Pandas, NumPy
* **Data Visualization:** Plotly Express, Plotly Graph Objects
* **Interactive Web App:** Streamlit
* **Environment:** PowerShell / VS Code

---

## ⚡ Step-by-Step Setup Guide

### 1. Prerequisites
Ensure Python is installed on your computer:
```powershell
python --version
```

### 2. Install Dependencies
Install all required libraries via pip:
```powershell
pip install -r requirements.txt
```

### 3. (Optional) Re-generate Dataset
To re-generate or refresh the raw 5,000 job postings dataset:
```powershell
python src/generate_dataset.py
```

### 4. Run the Data Processing Pipeline
Clean the raw data and generate the skill frequency and salary summary tables:
```powershell
python src/data_processing.py
```

### 5. View the Terminal Analytics Summary
Print key market metrics directly in your terminal:
```powershell
python src/run_eda.py
```

### 6. Launch the Interactive Dashboard
Launch the interactive web application in your browser:
```powershell
streamlit run app/app.py
```

---

## 🖥️ Dashboard Features
1. **Interactive Sidebar Filters:** Slice and dice data by Job Role, Country, Experience Level, Work Type, and Salary Range.
2. **Key Metric Cards (KPIs):** Instant view of Total Postings, Average Salary, Median Salary, % Remote Postings, and Top Skill.
3. **Market Overview:** Bar charts and donut charts showing distribution across roles, countries, company sizes, and work arrangements.
4. **Skills Demand & Salary ROI:** Top demanded skills vs highest paying skills, plus a Skill Value Quadrant map.
5. **Career Skill-Gap Analyzer:** Select your target role and check off your current skills to calculate your **Job Fit Score (%)** and receive recommendations for skills that maximize your salary potential.
