import os
import pandas as pd
import numpy as np

def process_job_market_data(raw_data_path, output_dir):
    print(f"Reading raw data from: {raw_data_path}")
    df = pd.read_csv(raw_data_path)

    # 1. Basic Cleaning
    df['job_title'] = df['job_title'].astype(str).str.strip()
    df['company_name'] = df['company_name'].astype(str).str.strip()
    df['posted_date'] = pd.to_datetime(df['posted_date'], errors='coerce')
    df['salary_year_usd'] = pd.to_numeric(df['salary_year_usd'], errors='coerce')

    # Drop any records with missing essential fields
    df_cleaned = df.dropna(subset=['job_title', 'job_role', 'salary_year_usd', 'skills']).copy()

    # 2. Explode skills into separate rows
    # Convert comma-separated string into Python list
    df_cleaned['skills_list'] = df_cleaned['skills'].apply(lambda x: [s.strip() for s in str(x).split(',') if s.strip()])
    
    # Explode to have one skill per row
    df_skills_exploded = df_cleaned.explode('skills_list').rename(columns={'skills_list': 'skill'})

    # 3. Compute Skills Demand & Salary Summary
    total_postings = len(df_cleaned)
    skill_summary = df_skills_exploded.groupby('skill').agg(
        job_count=('job_id', 'count'),
        avg_salary=('salary_year_usd', 'mean'),
        median_salary=('salary_year_usd', 'median')
    ).reset_index()

    skill_summary['demand_percentage'] = (skill_summary['job_count'] / total_postings) * 100
    skill_summary['avg_salary'] = skill_summary['avg_salary'].round(2)
    skill_summary['median_salary'] = skill_summary['median_salary'].round(2)
    skill_summary['demand_percentage'] = skill_summary['demand_percentage'].round(2)
    skill_summary = skill_summary.sort_values(by='job_count', ascending=False)

    # 4. Compute Top Skills by Role
    role_skill_summary = df_skills_exploded.groupby(['job_role', 'skill']).agg(
        job_count=('job_id', 'count'),
        avg_salary=('salary_year_usd', 'mean')
    ).reset_index()

    # Calculate percentage within role
    role_counts = df_cleaned['job_role'].value_counts().to_dict()
    role_skill_summary['postings_in_role'] = role_skill_summary['job_role'].map(role_counts)
    role_skill_summary['demand_percentage'] = ((role_skill_summary['job_count'] / role_skill_summary['postings_in_role']) * 100).round(2)
    role_skill_summary['avg_salary'] = role_skill_summary['avg_salary'].round(2)
    role_skill_summary = role_skill_summary.sort_values(by=['job_role', 'job_count'], ascending=[True, False])

    # 5. Export processed files
    os.makedirs(output_dir, exist_ok=True)
    cleaned_jobs_path = os.path.join(output_dir, "cleaned_jobs.csv")
    skills_summary_path = os.path.join(output_dir, "skills_summary.csv")
    role_skills_path = os.path.join(output_dir, "skills_by_role.csv")

    df_cleaned.drop(columns=['skills_list']).to_csv(cleaned_jobs_path, index=False)
    skill_summary.to_csv(skills_summary_path, index=False)
    role_skill_summary.to_csv(role_skills_path, index=False)

    print("\n--- Data Processing Completed Successfully ---")
    print(f"1. Cleaned Job Postings saved to: {cleaned_jobs_path} ({len(df_cleaned)} rows)")
    print(f"2. Overall Skills Summary saved to: {skills_summary_path} ({len(skill_summary)} unique skills)")
    print(f"3. Skills by Role saved to: {role_skills_path}")

    return df_cleaned, skill_summary, role_skill_summary

if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    raw_path = os.path.join(base_dir, "data", "raw", "job_postings.csv")
    processed_dir = os.path.join(base_dir, "data", "processed")

    process_job_market_data(raw_path, processed_dir)
