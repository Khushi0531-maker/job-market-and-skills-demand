import os
import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def generate_job_postings(num_records=5000, seed=42):
    random.seed(seed)
    np.random.seed(seed)

    roles = {
        "Data Analyst": {
            "titles": ["Data Analyst", "Junior Data Analyst", "Senior Data Analyst", "Lead Data Analyst", "Marketing Data Analyst", "Healthcare Data Analyst", "Financial Data Analyst"],
            "core_skills": ["SQL", "Excel", "Python", "Tableau", "Power BI", "R", "Statistics", "Google Sheets"],
            "optional_skills": ["Snowflake", "BigQuery", "Looker", "Alteryx", "Jira", "A/B Testing", "Git"],
            "base_salary_usd": {"Entry-level": (55000, 75000), "Mid-level": (75000, 105000), "Senior-level": (105000, 145000), "Lead/Principal": (140000, 185000)}
        },
        "Data Scientist": {
            "titles": ["Data Scientist", "Associate Data Scientist", "Senior Data Scientist", "Staff Data Scientist", "Data Scientist - NLP", "Data Scientist - Product"],
            "core_skills": ["Python", "SQL", "Machine Learning", "Scikit-Learn", "Pandas", "NumPy", "Statistics"],
            "optional_skills": ["R", "PyTorch", "TensorFlow", "AWS", "Docker", "Git", "Spark", "MLflow", "Deep Learning"],
            "base_salary_usd": {"Entry-level": (75000, 95000), "Mid-level": (100000, 140000), "Senior-level": (140000, 195000), "Lead/Principal": (190000, 260000)}
        },
        "Data Engineer": {
            "titles": ["Data Engineer", "Junior Data Engineer", "Senior Data Engineer", "Staff Data Engineer", "Big Data Engineer", "Cloud Data Architect"],
            "core_skills": ["Python", "SQL", "Spark", "AWS", "Airflow", "ETL", "Kafka"],
            "optional_skills": ["GCP", "Azure", "Snowflake", "Databricks", "dbt", "Docker", "Kubernetes", "Scala", "PostgreSQL", "NoSQL"],
            "base_salary_usd": {"Entry-level": (75000, 98000), "Mid-level": (105000, 145000), "Senior-level": (145000, 205000), "Lead/Principal": (195000, 270000)}
        },
        "Machine Learning Engineer": {
            "titles": ["Machine Learning Engineer", "Junior ML Engineer", "Senior ML Engineer", "Lead MLOps Engineer", "AI/ML Engineer", "Computer Vision Engineer"],
            "core_skills": ["Python", "PyTorch", "TensorFlow", "Docker", "MLOps", "Git", "Kubernetes"],
            "optional_skills": ["AWS", "GCP", "C++", "FastAPI", "Hugging Face", "MLflow", "Kafka", "Linux", "CI/CD"],
            "base_salary_usd": {"Entry-level": (85000, 110000), "Mid-level": (120000, 160000), "Senior-level": (160000, 220000), "Lead/Principal": (210000, 290000)}
        },
        "Business Intelligence Analyst": {
            "titles": ["BI Analyst", "Senior BI Analyst", "Business Intelligence Developer", "BI Reporting Specialist", "Analytics Engineer"],
            "core_skills": ["SQL", "Power BI", "Tableau", "DAX", "Data Modeling", "Excel"],
            "optional_skills": ["Python", "Snowflake", "dbt", "Looker", "SSIS", "SSRS", "Azure"],
            "base_salary_usd": {"Entry-level": (60000, 80000), "Mid-level": (80000, 110000), "Senior-level": (110000, 150000), "Lead/Principal": (145000, 190000)}
        },
        "Software Engineer": {
            "titles": ["Software Engineer", "Backend Developer", "Full Stack Engineer", "Senior Software Engineer", "DevOps Engineer"],
            "core_skills": ["Python", "Java", "JavaScript", "Git", "SQL", "Docker", "REST API"],
            "optional_skills": ["React", "Node.js", "AWS", "Kubernetes", "C#", "Go", "PostgreSQL", "Microservices"],
            "base_salary_usd": {"Entry-level": (70000, 95000), "Mid-level": (100000, 140000), "Senior-level": (140000, 195000), "Lead/Principal": (185000, 250000)}
        }
    }

    companies = [
        ("Google", "Enterprise (5000+)"), ("Microsoft", "Enterprise (5000+)"), ("Amazon", "Enterprise (5000+)"),
        ("Meta", "Enterprise (5000+)"), ("Netflix", "Large (501-5000)"), ("Spotify", "Large (501-5000)"),
        ("Stripe", "Large (501-5000)"), ("Snowflake", "Large (501-5000)"), ("Databricks", "Large (501-5000)"),
        ("FinTech Innovations", "Medium (51-500)"), ("HealthAI Labs", "Medium (51-500)"), ("NextGen Retail", "Medium (51-500)"),
        ("CloudScale Analytics", "Startup (1-50)"), ("DataPulse Systems", "Startup (1-50)"), ("BioTech Dynamics", "Startup (1-50)"),
        ("OmniCommerce", "Large (501-5000)"), ("Quantum Solutions", "Medium (51-500)"), ("Urban Logistics", "Medium (51-500)")
    ]

    countries = {
        "United States": 1.0,
        "United Kingdom": 0.82,
        "Canada": 0.88,
        "Germany": 0.80,
        "India": 0.35,
        "Australia": 0.90
    }
    
    country_weights = [0.45, 0.15, 0.12, 0.10, 0.10, 0.08]
    work_types = ["Remote", "Hybrid", "On-site"]
    work_type_weights = [0.42, 0.36, 0.22]
    exp_levels = ["Entry-level", "Mid-level", "Senior-level", "Lead/Principal"]
    exp_weights = [0.20, 0.45, 0.28, 0.07]

    records = []
    base_date = datetime.now() - timedelta(days=365)

    for i in range(1, num_records + 1):
        role_category = random.choices(
            list(roles.keys()), 
            weights=[0.30, 0.22, 0.20, 0.12, 0.10, 0.06]
        )[0]
        role_data = roles[role_category]

        job_title = random.choice(role_data["titles"])
        exp_level = random.choices(exp_levels, weights=exp_weights)[0]
        work_type = random.choices(work_types, weights=work_type_weights)[0]
        company_name, company_size = random.choice(companies)
        
        country = random.choices(list(countries.keys()), weights=country_weights)[0]
        multiplier = countries[country]

        min_sal, max_sal = role_data["base_salary_usd"][exp_level]
        raw_salary = random.randint(min_sal, max_sal)
        # Apply country factor with a slight variance
        salary_usd = int(raw_salary * multiplier * random.uniform(0.92, 1.08))

        # Sample skills
        num_core = random.randint(3, len(role_data["core_skills"]))
        num_opt = random.randint(1, min(4, len(role_data["optional_skills"])))
        chosen_skills = set(random.sample(role_data["core_skills"], num_core) + 
                            random.sample(role_data["optional_skills"], num_opt))
        skills_str = ", ".join(sorted(chosen_skills))

        posted_days_ago = random.randint(0, 360)
        posted_date = (base_date + timedelta(days=posted_days_ago)).strftime("%Y-%m-%d")

        records.append({
            "job_id": f"JOB_{10000 + i}",
            "job_title": job_title,
            "job_role": role_category,
            "company_name": company_name,
            "company_size": company_size,
            "country": country,
            "work_type": work_type,
            "experience_level": exp_level,
            "salary_year_usd": salary_usd,
            "skills": skills_str,
            "posted_date": posted_date
        })

    df = pd.DataFrame(records)
    return df

if __name__ == "__main__":
    out_dir = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "job_postings.csv")
    
    print("Generating 5,000 realistic job postings...")
    df = generate_job_postings(num_records=5000)
    df.to_csv(out_path, index=False)
    print(f"Dataset successfully created at: {out_path}")
    print(f"Total Rows: {len(df)}")
    print(f"Columns: {list(df.columns)}")
