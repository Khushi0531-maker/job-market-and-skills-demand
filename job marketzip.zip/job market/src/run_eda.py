import os
import pandas as pd

def run_eda_summary():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cleaned_path = os.path.join(base_dir, "data", "processed", "cleaned_jobs.csv")
    skills_summary_path = os.path.join(base_dir, "data", "processed", "skills_summary.csv")
    skills_role_path = os.path.join(base_dir, "data", "processed", "skills_by_role.csv")

    df = pd.read_csv(cleaned_path)
    skills_df = pd.read_csv(skills_summary_path)
    skills_role_df = pd.read_csv(skills_role_path)

    print("==========================================================")
    print("      JOB MARKET & SKILLS DEMAND ANALYTICS REPORT         ")
    print("==========================================================\n")

    # 1. Overview
    print(f"Total Postings Analyzed: {len(df):,}")
    print(f"Overall Average Salary : ${df['salary_year_usd'].mean():,.2f}")
    print(f"Overall Median Salary  : ${df['salary_year_usd'].median():,.2f}\n")

    # 2. Demand by Role
    print("--- 1. JOB POSTINGS & AVERAGE SALARY BY ROLE ---")
    role_stats = df.groupby('job_role').agg(
        Count=('job_id', 'count'),
        Avg_Salary=('salary_year_usd', 'mean'),
        Median_Salary=('salary_year_usd', 'median')
    ).sort_values(by='Count', ascending=False)
    role_stats['Avg_Salary'] = role_stats['Avg_Salary'].map('${:,.0f}'.format)
    role_stats['Median_Salary'] = role_stats['Median_Salary'].map('${:,.0f}'.format)
    print(role_stats.to_string())
    print()

    # 3. Work Arrangement
    print("--- 2. WORK ARRANGEMENT BREAKDOWN ---")
    work_stats = df['work_type'].value_counts(normalize=True) * 100
    for w_type, pct in work_stats.items():
        print(f"  • {w_type:<10}: {pct:.1f}%")
    print()

    # 4. Top 10 Most Demanded Skills
    print("--- 3. TOP 10 IN-DEMAND SKILLS (OVERALL) ---")
    top_10_skills = skills_df.head(10)[['skill', 'job_count', 'demand_percentage', 'avg_salary']]
    top_10_skills.columns = ['Skill', 'Count', 'Demand %', 'Avg Salary']
    top_10_skills['Avg Salary'] = top_10_skills['Avg Salary'].map('${:,.0f}'.format)
    print(top_10_skills.to_string(index=False))
    print()

    # 5. Top 5 Highest-Paying Skills
    print("--- 4. TOP 5 HIGHEST PAYING SKILLS ---")
    high_pay_skills = skills_df.sort_values(by='avg_salary', ascending=False).head(5)[['skill', 'demand_percentage', 'avg_salary']]
    high_pay_skills.columns = ['Skill', 'Demand %', 'Avg Salary']
    high_pay_skills['Avg Salary'] = high_pay_skills['Avg Salary'].map('${:,.0f}'.format)
    print(high_pay_skills.to_string(index=False))
    print()

    # 6. Must-Have Skill per Role
    print("--- 5. #1 TOP SKILL FOR EACH ROLE ---")
    idx = skills_role_df.groupby('job_role')['job_count'].idxmax()
    top_per_role = skills_role_df.loc[idx][['job_role', 'skill', 'demand_percentage', 'avg_salary']]
    top_per_role.columns = ['Role', 'Top Skill', 'Demand %', 'Avg Salary']
    top_per_role['Avg Salary'] = top_per_role['Avg Salary'].map('${:,.0f}'.format)
    print(top_per_role.to_string(index=False))
    print("\n==========================================================")

if __name__ == "__main__":
    run_eda_summary()
