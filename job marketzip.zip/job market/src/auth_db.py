import os
import sqlite3
import hashlib
import hmac
from datetime import datetime

# Path to database file
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "data", "users.db")

# Fixed salt for hashing (in production, per-user salts are standard)
SALT = b"job_market_analytics_salt_2026"

def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            email TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 2. User Career Assessments Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_assessments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            assessment_name TEXT NOT NULL,
            target_role TEXT NOT NULL,
            skills_possessed TEXT,
            fit_score REAL NOT NULL,
            missing_skills TEXT,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    # 3. User Saved/Bookmarked Jobs Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS saved_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            job_id TEXT NOT NULL,
            job_title TEXT,
            job_role TEXT,
            company_name TEXT,
            salary_year_usd INTEGER,
            country TEXT,
            work_type TEXT,
            skills TEXT,
            saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(user_id, job_id)
        )
    """)

    conn.commit()
    conn.close()

def hash_password(password: str) -> str:
    key = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        SALT,
        100000
    )
    return key.hex()

def verify_password(password: str, hashed: str) -> bool:
    new_hash = hash_password(password)
    return hmac.compare_digest(new_hash, hashed)

def register_user(username: str, password: str, email: str = ""):
    username = username.strip()
    if not username:
        return False, "Username cannot be empty."
    if len(password) < 4:
        return False, "Password must be at least 4 characters long."

    conn = get_connection()
    cursor = conn.cursor()
    try:
        pwd_hash = hash_password(password)
        cursor.execute(
            "INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)",
            (username, pwd_hash, email.strip())
        )
        conn.commit()
        user_id = cursor.lastrowid
        return True, {"id": user_id, "username": username, "email": email}
    except sqlite3.IntegrityError:
        return False, f"Username '{username}' is already taken. Please choose another."
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()

def authenticate_user(username: str, password: str):
    username = username.strip()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, password_hash, email FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()

    if row and verify_password(password, row["password_hash"]):
        return True, {"id": row["id"], "username": row["username"], "email": row["email"]}
    return False, "Invalid username or password."

# --- ASSESSMENT OPERATIONS ---
def save_user_assessment(user_id: int, assessment_name: str, target_role: str, skills_possessed: list, fit_score: float, missing_skills: list, notes: str = ""):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO user_assessments (user_id, assessment_name, target_role, skills_possessed, fit_score, missing_skills, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            assessment_name.strip() or f"{target_role} Assessment ({datetime.now().strftime('%b %d, %Y')})",
            target_role,
            ", ".join(skills_possessed),
            fit_score,
            ", ".join(missing_skills),
            notes.strip()
        ))
        conn.commit()
        return True, "Assessment saved successfully!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()

def get_user_assessments(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, assessment_name, target_role, skills_possessed, fit_score, missing_skills, notes, created_at
        FROM user_assessments
        WHERE user_id = ?
        ORDER BY created_at DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def delete_user_assessment(assessment_id: int, user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM user_assessments WHERE id = ? AND user_id = ?", (assessment_id, user_id))
    conn.commit()
    conn.close()
    return True

# --- SAVED JOBS (BOOKMARKS) OPERATIONS ---
def save_job_bookmark(user_id: int, job: dict):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO saved_jobs (user_id, job_id, job_title, job_role, company_name, salary_year_usd, country, work_type, skills)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            str(job.get("job_id", "")),
            job.get("job_title", ""),
            job.get("job_role", ""),
            job.get("company_name", ""),
            int(job.get("salary_year_usd", 0)),
            job.get("country", ""),
            job.get("work_type", ""),
            job.get("skills", "")
        ))
        conn.commit()
        return True, "Job saved to your bookmarks!"
    except sqlite3.IntegrityError:
        return False, "This job is already saved in your bookmarks."
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()

def get_saved_jobs(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, job_id, job_title, job_role, company_name, salary_year_usd, country, work_type, skills, saved_at
        FROM saved_jobs
        WHERE user_id = ?
        ORDER BY saved_at DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def delete_saved_job(saved_job_id: int, user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM saved_jobs WHERE id = ? AND user_id = ?", (saved_job_id, user_id))
    conn.commit()
    conn.close()
    return True

# Initialize DB on load
init_db()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at:", DB_PATH)
